package examples;

import bitmark.DownloadBitmarkFile;
import bitmark.client.BitmarkAPIClient;


public class DownloadAssetFile {

    public static void main(String[] args) throws Exception {
//        String seed = "5XEECt9dikx44tRPKpx3S8juB5Y7ME1KAMczMojDYnhgKnEHWZoanDi";
//        String bitmarkId = "649db122f64acb6c663baf724a75566c896623e4af3c29b5c824f022e8ea68f8";
        String seed = args[0];
        String bitmarkId = args[1];
        String env = args[2]; //testnet or livenet

        DownloadBitmarkFile downloadBitmarkFile = new DownloadBitmarkFile(seed, env);

        // decrypt the asset file
        String plaintext = downloadBitmarkFile.accessFileContent(bitmarkId);
        System.out.println(plaintext);
    }
}
