package bitmark.client;

import org.apache.commons.io.IOUtils;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import javax.net.ssl.*;
import java.io.InputStreamReader;
import java.net.URL;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;

public class BitmarkAPIClient {
    public static final String LIVENET = "livenet";
    public static final String TESTNET = "testnet";

    String apiEndpoint;
    String keyEndpoint;
    private JSONParser parser;

    public BitmarkAPIClient(String network) {
        switch (network) {
            case LIVENET:
                this.apiEndpoint = "https://dedicated-api.bitmark.com";
                this.keyEndpoint = "https://dedicated-api.bitmark.com";
                break;
            case TESTNET:
                this.apiEndpoint = "https://dedicated-api.test.bitmark.com";
                this.keyEndpoint = "https://dedicated-api.test.bitmark.com";
                break;
        }

        parser = new JSONParser();
    }

    public JSONObject getAssetAccess(String owner, String bitmarkId, long timestamp, String signature) throws Exception {
        URL obj = new URL(this.apiEndpoint + "/v1/bitmarks/" + bitmarkId + "/asset");
        HttpsURLConnection httpsConn = (HttpsURLConnection) obj.openConnection();
        httpsConn.setRequestProperty("requester", owner);
        httpsConn.setRequestProperty("timestamp", Long.toString(timestamp));
        httpsConn.setRequestProperty("signature", signature);
        //trust all
//        httpsConn.setSSLSocketFactory(getSSLSocketFactory(httpsConn));
//        httpsConn.setHostnameVerifier((hostname, session) -> true);
        if (httpsConn.getResponseCode() != 200) {
            throw new Exception(IOUtils.toString(httpsConn.getInputStream(), "UTF-8"));
        }

        return (JSONObject) parser.parse(new InputStreamReader(httpsConn.getInputStream(), "UTF-8"));
    }

    public byte[] downloadAssetContent(String url) throws Exception {
        URL assetResourceUrl = new URL(url);
        HttpsURLConnection httpsConn = (HttpsURLConnection) assetResourceUrl.openConnection();
        //trust all
//        httpsConn.setSSLSocketFactory(getSSLSocketFactory(httpsConn));
//        httpsConn.setHostnameVerifier((hostname, session) -> true);
        if (httpsConn.getResponseCode() != 200) {
            throw new Exception(IOUtils.toString(httpsConn.getInputStream(), "UTF-8"));
        }
        return IOUtils.toByteArray(httpsConn.getInputStream());
    }

    public String getEncrPubkey(String accountNumer) throws Exception {
        URL url = new URL(this.keyEndpoint + "/" + accountNumer);
        HttpsURLConnection httpsConn = (HttpsURLConnection) url.openConnection();
        //trust all
//        httpsConn.setSSLSocketFactory(getSSLSocketFactory(httpsConn));
//        httpsConn.setHostnameVerifier((hostname, session) -> true);
        if (httpsConn.getResponseCode() != 200) {
            throw new Exception(IOUtils.toString(httpsConn.getInputStream(), "UTF-8"));
        }

        JSONObject publicKey = (JSONObject) parser.parse(new InputStreamReader(httpsConn.getInputStream(), "UTF-8"));
        return (String) publicKey.get("encryption_pubkey");
    }

    private SSLSocketFactory getSSLSocketFactory(HttpsURLConnection connection) {
        try {
            SSLContext sc = SSLContext.getInstance("TLS");
            sc.init(null, getTrustManager(), new java.security.SecureRandom());
            return sc.getSocketFactory();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return connection.getSSLSocketFactory();
    }

    private TrustManager[] getTrustManager() {
        return new TrustManager[]{
                new X509TrustManager() {
                    public java.security.cert.X509Certificate[] getAcceptedIssuers() {
                        return new java.security.cert.X509Certificate[]{};
                    }

                    public void checkClientTrusted(X509Certificate[] chain, String authType)
                            throws CertificateException {
                    }

                    public void checkServerTrusted(X509Certificate[] chain, String authType)
                            throws CertificateException {
                    }

                }
        };
    }
}