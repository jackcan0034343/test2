package bitmark.crypto;

import javax.xml.bind.DatatypeConverter;
import java.util.Arrays;

public class Utils {

    public String signRequest(String action, String resource, String requester, String ts, byte[] sk) throws Exception {
        byte[] sig = new byte[SodiumLibrary.sodium().crypto_sign_bytes()];
        byte[] msg = String.join("|", action, resource, requester, ts).getBytes();
        int r = SodiumLibrary.sodium().crypto_sign_detached(sig, null, msg, msg.length, sk);
        if (r != 0) {
            throw new Exception("unable to sign message");
        }
        return DatatypeConverter.printHexBinary(sig);
    }

    public byte[] decryptDataKey(String encDataKey, String peerPublicKey, byte[] sk) throws Exception {
        byte[] msg = DatatypeConverter.parseHexBinary(encDataKey);
        byte[] plaintext = new byte[msg.length - SodiumLibrary.sodium().crypto_box_macbytes() - SodiumLibrary.sodium().crypto_box_noncebytes()];
        byte[] ciphertext = Arrays.copyOfRange(msg, 24, msg.length);
        byte[] nonce = Arrays.copyOfRange(msg, 0, 24);
        byte[] pk = DatatypeConverter.parseHexBinary(peerPublicKey);

        int r = SodiumLibrary.sodium().crypto_box_open_easy(plaintext, ciphertext, ciphertext.length, nonce, pk, sk);
        if (r != 0) {
            throw new Exception("unable to decrypt data key");
        }
        return plaintext;
    }

    public byte[] decryptAssetFile(byte[] ciphertext, byte[] key) throws Exception {
        byte[] plaintext = new byte[ciphertext.length - SodiumLibrary.sodium().crypto_aead_chacha20poly1305_ietf_abytes()];
        long[] mlen = new long[1];
        byte[] nonce = new byte[12];
        int r = SodiumLibrary.sodium().crypto_aead_chacha20poly1305_ietf_decrypt(plaintext, mlen, null, ciphertext, ciphertext.length, null, 0, nonce, key);
        if (r != 0) {
            throw new Exception("unable to decrypt asset file");
        }
        return Arrays.copyOfRange(plaintext, 0, (int) mlen[0]);
    }
}