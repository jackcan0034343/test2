package bitmark.crypto;


import org.apache.commons.lang3.ArrayUtils;
import org.bouncycastle.jcajce.provider.digest.SHA3;

import java.util.Arrays;

public class Account {
    final static int algorithmShift = 4;
    final static int pubkeyMask = 0x01;
    final static int testnetMask = 0x02;
    final static int algEd25519 = 1;
    final static int accountChecksumLength = 4;

    private final static byte[] seedNonce = new byte[24];
    private final static byte[] authSeedCount = new byte[]{
            0, 0, 0, 0, 0, 0, 0, 0,
            0, 0, 0, 0, 0, 0, (byte) 0x03, (byte) 0xe7
    };
    private static byte[] encrSeedCount = new byte[]{
            0, 0, 0, 0, 0, 0, 0, 0,
            0, 0, 0, 0, 0, 0, (byte) 0x03, (byte) 0xe8
    };

    private static byte[] seedHeader = new byte[]{(byte) 0x5a, (byte) 0xfe, (byte) 0x01};

    private String network;

    private byte[] authPrivateKey = new byte[SodiumLibrary.sodium().crypto_sign_secretkeybytes()];
    private byte[] authPublicKey = new byte[SodiumLibrary.sodium().crypto_sign_publickeybytes()];

    private byte[] encrPrivateKey = new byte[SodiumLibrary.sodium().crypto_box_secretkeybytes()];
    private byte[] encrPublicKey = new byte[SodiumLibrary.sodium().crypto_box_publickeybytes()];

    private byte[] acctBytes;

    static{
        try {
            System.loadLibrary("libsodium");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public Account(String seed) throws Exception {
        byte[] seedBytes = Base58.decode(seed);
        if (seedBytes.length != 40) {
            throw new Exception("invalid seed length");
        }

        byte[] header = Arrays.copyOfRange(seedBytes, 0, 3);
        if (!Arrays.equals(header, seedHeader)) {
            throw new Exception("invalid seed header");
        }

        byte[] prefix = Arrays.copyOfRange(seedBytes, 3, 4);
        this.network = "livenet";
        if (prefix[0] == 0x01) {
            this.network = "testnet";
        }

        SHA3.DigestSHA3 digestSHA3 = new SHA3.Digest256();
        byte[] expectedChecksum = Arrays.copyOfRange(seedBytes, 36, 40);
        byte[] actualChecksum = Arrays.copyOfRange(
                digestSHA3.digest(Arrays.copyOfRange(seedBytes, 0, 36)),
                0, 4);
        if (!Arrays.equals(actualChecksum, expectedChecksum)) {
            throw new Exception("invalid seed checksum");
        }

        byte[] core = Arrays.copyOfRange(seedBytes, 4, 36);

        // generate auth keypair
        byte[] authSeed = new byte[SodiumLibrary.sodium().crypto_secretbox_macbytes() + authSeedCount.length];
        int r = SodiumLibrary.sodium().crypto_secretbox_easy(authSeed, authSeedCount, authSeedCount.length, seedNonce, core);
        if (r != 0) {
            throw new Exception("unable to generate auth seed");
        }
        r = SodiumLibrary.sodium().crypto_sign_seed_keypair(authPublicKey, authPrivateKey, authSeed);
        if (r != 0) {
            throw new Exception("unable to generate auth keypair");
        }

        // generate encr keypair
        r = SodiumLibrary.sodium().crypto_secretbox_easy(encrPrivateKey, encrSeedCount, encrSeedCount.length, seedNonce, core);
        if (r != 0) {
            throw new Exception("unable to generate encr seed");
        }

        r = SodiumLibrary.sodium().crypto_scalarmult_base(encrPublicKey, encrPrivateKey);
        if (r != 0) {
            throw new Exception("unable to generate encr keypair");
        }

        byte[] keyVariant = new byte[]{(byte) (algEd25519 << algorithmShift | pubkeyMask)};
        if (network == "testnet") {
            keyVariant[0] |= testnetMask;
        }

        acctBytes = ArrayUtils.addAll(keyVariant, authPublicKey);
    }

    public String Network() {
        return network;
    }

    public byte[] getAuthPrivateKey() {
        return authPrivateKey;
    }

    public byte[] getEncrPrivateKey() {
        return encrPrivateKey;
    }

    public String getAccountNumber() {
        SHA3.DigestSHA3 sha3 = new SHA3.Digest256();
        byte[] digest = sha3.digest(acctBytes);
        byte[] checksum = Arrays.copyOfRange(digest, 0, accountChecksumLength);
        return Base58.encode(ArrayUtils.addAll(acctBytes, checksum));
    }
}
