package bitmark.crypto;

import com.sun.jna.Library;
import com.sun.jna.Native;

public class SodiumLibrary {
    private static String libPath;

    public static void setLibraryPath(String libraryPath) {
        SodiumLibrary.libPath = libraryPath;
    }

    public static Sodium sodium() {
        Sodium sodium = SingletonHelper.INSTANCE;
        return sodium;
    }

    public interface Sodium extends Library {
        // Secret-key authenticated encryption
        int crypto_secretbox_macbytes();

        int crypto_secretbox_easy(byte[] c, byte[] m, long mlen, byte[] n, byte[] k);

        // The IETF ChaCha20-Poly1305 construction
        int crypto_aead_chacha20poly1305_ietf_abytes();

        int crypto_aead_chacha20poly1305_ietf_decrypt(byte[] m, long[] mlen, byte[] nsec, byte[] c, long clen, byte[] ad, long adlen, byte[] npub, byte[] key);

        // Public-key authenticated encryption
        int crypto_box_publickeybytes();

        int crypto_box_secretkeybytes();

        int crypto_box_macbytes();

        int crypto_box_noncebytes();

        int crypto_scalarmult_base(byte[] q, byte[] n);

        int crypto_box_open_easy(byte[] m, byte[] c, long clen, byte[] n, byte[] pk, byte[] sk);


        // Public-key signatures
        int crypto_sign_publickeybytes();

        int crypto_sign_secretkeybytes();

        int crypto_sign_bytes();

        int crypto_sign_seed_keypair(byte[] pk, byte[] sk, byte[] seed);

        int crypto_sign_detached(byte[] sig, long[] siglen, byte[] m, long mlen, byte[] sk);
    }

    private static final class SingletonHelper {
        public static final Sodium INSTANCE = (Sodium) Native.loadLibrary("sodium", Sodium.class);
    }
}