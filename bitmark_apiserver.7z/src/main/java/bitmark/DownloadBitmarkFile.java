package bitmark;

import bitmark.client.BitmarkAPIClient;
import bitmark.crypto.Account;
import bitmark.crypto.Utils;
import org.json.simple.JSONObject;

public class DownloadBitmarkFile {

    private Account account;
    private BitmarkAPIClient bitmarkAPIClient;
    private Utils utils;

    public DownloadBitmarkFile(String seed, String env) throws Exception {
        this.account = new Account(seed);
        this.bitmarkAPIClient = new BitmarkAPIClient(env);
        this.utils = new Utils();
    }

    public String accessFileContent(String bitmarkId) throws Exception {
        // generate signature for this api request
        long ts = System.currentTimeMillis();
        String sig = utils.signRequest("downloadAsset", bitmarkId, account.getAccountNumber(), String.valueOf(ts), account.getAuthPrivateKey());

        // get the access to asset
        JSONObject access = bitmarkAPIClient.getAssetAccess(account.getAccountNumber(), bitmarkId, ts, sig);
        JSONObject sessionData = (JSONObject) access.get("session_data");
        String sender = (String) access.get("sender");
        String url = (String) access.get("url");

        // decrypt the data key
        byte[] key = utils.decryptDataKey(
                (String) sessionData.get("enc_data_key"),
                bitmarkAPIClient.getEncrPubkey(sender),
                account.getEncrPrivateKey());

        // download the encrypted content
        byte[] ciphertext = bitmarkAPIClient.downloadAssetContent(url);

        // decrypt the asset file
        byte[] plaintext = utils.decryptAssetFile(ciphertext, key);

        return new String(plaintext, "UTF-8");
    }
}
